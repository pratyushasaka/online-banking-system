package com.bank.contact;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Contact")
public class Contact extends HttpServlet {
private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Contact() {
        super();
        // TODO Auto-generated constructor stub
    }

/**
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
*/
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    int amunt = Integer. parseInt(request.getParameter("amount"));
String url = "jdbc:mysql://localhost:3306/intern";
String username = "root";
String password = "pratyu@123";
String ac1=request.getParameter("sacnum");
String ac2=request.getParameter("racnum");


try
{
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection(url,username,password);
PreparedStatement st = con.prepareStatement("select * from bank where num=?");
st.setString(1,ac1);
ResultSet rs = st.executeQuery();
while(rs.next())
{
int amt = rs.getInt("amount");

HttpSession session = request.getSession();
session.setAttribute("amnt", amt);


}
HttpSession session = request.getSession();
int val = (int)session.getAttribute("amnt");
int newval = val-amunt;
PreparedStatement ps = con.prepareStatement("update bank set amount = ? where num = ?");
ps.setInt(1, newval);
ps.setString(2, ac1);
int sr = ps.executeUpdate();
if(sr>0)
{
PreparedStatement pt = con.prepareStatement("insert into bankdetails(sacnum,racnum,amount,balance) values(?,?,?,?)");
pt.setString(1, ac1);
pt.setString(2, ac2);
pt.setInt(3, amunt);
pt.setInt(4, newval);
pt.executeUpdate();
}
else
{
System.out.print("updation UnSuccessful");
}
response.sendRedirect("retrieve.jsp");
}

catch(Exception e) {

e.printStackTrace();
}
}

}
